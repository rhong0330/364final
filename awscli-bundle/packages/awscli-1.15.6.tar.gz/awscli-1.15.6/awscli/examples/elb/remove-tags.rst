**To remove tags from a load balancer**

This example removes a tag from the specified load balancer.

Command::

  aws elb remove-tags --load-balancer-name my-load-balancer --tags project
